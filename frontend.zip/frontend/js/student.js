/* =====================================================================
   student.js  -  STUDENT PANEL  (student.html)
   FR-05 browse, FR-06 search/filter, FR-07 details, FR-08 register,
   FR-09 my records, FR-11 notifications, FR-13 status
   ===================================================================== */
const user = guard("student");

let myRegs = [];            // my registrations (each has .event)
const seenKey = "ev_seen_" + (user ? user.id : "x");

async function start() {
  initShell(user, onSection);

  // fill filter dropdowns (lists come from config.js)
  $("#f-category").innerHTML = options(CONFIG.CATEGORIES, "", "All categories");
  $("#f-status").innerHTML = `<option value="all">All statuses</option>` +
    Object.entries(CONFIG.STATUS_LABELS).map(([k, v]) => `<option value="${k}">${v}</option>`).join("");

  // FR-06: search + filters re-run the search each time they change
  let timer;
  $("#f-search").oninput = () => { clearTimeout(timer); timer = setTimeout(loadBrowse, 250); };
  $("#f-category").onchange = $("#f-status").onchange = loadBrowse;
  $("#f-clear").onclick = () => { $("#f-search").value = ""; $("#f-category").value = "all"; $("#f-status").value = "all"; loadBrowse(); };

  await refreshMine();
  updateBadge();
}

/** Runs every time a sidebar section is opened */
function onSection(name) {
  if (name === "dashboard") loadDashboard();
  if (name === "browse") loadBrowse();
  if (name === "registrations") loadRegistrations();
  if (name === "attendance") loadAttendance();
  if (name === "notifications") loadNotices();
}

async function refreshMine() { myRegs = (await safe(() => API.myRegistrations())) || []; }
const isRegistered = id => myRegs.find(r => r.eventId === id);

/* ------------------------------------------------------------ DASHBOARD */
async function loadDashboard() {
  $("#welcome-name").textContent = user.name;
  await refreshMine();
  const all = (await safe(() => API.getEvents())) || [];
  const notices = (await safe(() => API.getNotices())) || [];
  const seen = Number(localStorage.getItem(seenKey) || 0);
  const open = all.filter(e => e.status === "open");
  const upcomingMine = myRegs.filter(r => r.event.status !== "completed").sort((a, b) => a.event.date.localeCompare(b.event.date));

  // banner = my next registered event
  const next = upcomingMine[0];
  $("#next-event").innerHTML = next
    ? `<div class="tag">Your next event</div><h3>${esc(next.event.title)}</h3>
       <p class="muted">◷ ${fmtDate(next.event.date)} · ${fmtTime(next.event.time)} &nbsp; ⌖ ${esc(next.event.venue)}</p>`
    : `<div class="tag">Your next event</div><h3>Nothing yet</h3><p class="muted">You have not registered for any upcoming event. Browse events to get started!</p>`;

  $("#stat-regs").textContent = myRegs.length;
  $("#stat-open").textContent = open.length;
  $("#stat-upcoming").textContent = upcomingMine.length;
  $("#stat-notices").textContent = notices.filter(n => new Date(n.createdAt).getTime() > seen).length;
  $("#stat-attended").textContent = myRegs.filter(r => r.attendance === "present").length;

  $("#dash-open").innerHTML = open.slice(0, 3).map(e => eventCardHTML(e, `<button class="btn btn-sm" data-view="${e.id}">View details</button>`)).join("")
    || `<div class="empty">No events are open for registration right now.</div>`;
  $("#dash-notices").innerHTML = noticesHTML(notices.slice(0, 3), { seenAt: seen });
  bindViewButtons($("#dash-open"));
}

/* ------------------------------------------------------- BROWSE (FR-05/06) */
async function loadBrowse() {
  await refreshMine();
  const list = (await safe(() => API.getEvents({
    search: $("#f-search").value.trim(), category: $("#f-category").value, status: $("#f-status").value
  }))) || [];
  $("#browse-count").textContent = list.length + (list.length === 1 ? " event found" : " events found");
  $("#browse-list").innerHTML = list.map(e => {
    const mine = isRegistered(e.id);
    return eventCardHTML(e, `
      <button class="btn btn-ghost btn-sm" data-view="${e.id}">Details</button>
      ${mine ? `<span class="badge open">✔ Registered</span>`
             : e.status === "open" ? `<button class="btn btn-sm" data-reg="${e.id}">Register</button>` : ""}`);
  }).join("") || `<div class="empty" style="grid-column:1/-1">No events match your search.</div>`;
  bindViewButtons($("#browse-list"));
  $$("[data-reg]", $("#browse-list")).forEach(b => b.onclick = () => openRegisterForm(Number(b.dataset.reg)));
}

function bindViewButtons(root) {
  $$("[data-view]", root).forEach(b => b.onclick = () => openDetails(Number(b.dataset.view)));
}

/* ------------------------------------------------------ DETAILS (FR-07) */
async function openDetails(id) {
  const e = await safe(() => API.getEvent(id));
  if (!e) return;
  const mine = isRegistered(id);
  const seatsLeft = Math.max(0, e.capacity - e.registered);
  let action = "";
  if (mine) action = `<span class="badge open">✔ You are registered</span>`;
  else if (e.status === "open") action = `<button class="btn" id="d-register">Register now</button>`;
  else action = `<span class="muted">${e.status === "upcoming" ? "Registration opens on " + fmtDate(e.regOpen)
      : e.status === "completed" ? "This event is over." : seatsLeft === 0 ? "This event is full." : "Registration is closed."}</span>`;

  const m = openModal(e.title, `
    <div style="display:flex;gap:8px;flex-wrap:wrap"><span class="badge cat">${esc(e.category)}</span>${statusBadge(e.status)}</div>
    <p style="margin-top:14px">${esc(e.description)}</p>
    <div class="detail-list">
      <div class="item"><span>Date</span><b>${fmtDate(e.date)}</b></div>
      <div class="item"><span>Time</span><b>${fmtTime(e.time)}</b></div>
      <div class="item"><span>Venue</span><b>${esc(e.venue)}</b></div>
      <div class="item"><span>Fee</span><b>${fee(e.fee)}</b></div>
      <div class="item"><span>Registration window</span><b>${fmtDate(e.regOpen)} → ${fmtDate(e.regDeadline)}</b></div>
      <div class="item"><span>Seats</span><b>${e.registered} / ${e.capacity} filled (${seatsLeft} left)</b></div>
      <div class="item"><span>Organizer</span><b>${esc(e.organizerName)}</b></div>
      <div class="item"><span>Contact</span><b>${esc(e.contact) || "-"}</b></div>
    </div>
    <div class="form-actions" style="align-items:center">${action}<button class="btn btn-ghost" data-close>Close</button></div>`);
  const btn = $("#d-register", m);
  if (btn) btn.onclick = () => openRegisterForm(id);
}

/* ------------------------------------------- REGISTRATION FORM (FR-08) */
async function openRegisterForm(id) {
  const e = await safe(() => API.getEvent(id));
  if (!e) return;
  const m = openModal("Register for " + e.title, `
    <form id="reg-form" class="form-grid" novalidate>
      <div class="field"><label>Full name <span class="req">*</span></label><input name="name" value="${esc(user.name)}"></div>
      <div class="field"><label>Email <span class="req">*</span></label><input type="email" name="email" value="${esc(user.email)}"></div>
      <div class="field"><label>Enrollment number</label><input name="enrollment" value="${esc(user.enrollment)}"></div>
      <div class="field"><label>Phone <span class="req">*</span></label><input name="phone" placeholder="10-digit mobile number"></div>
      <div class="field"><label>Department</label><select name="department">${options(CONFIG.DEPARTMENTS, user.department)}</select></div>
      <div class="field"><label>Year</label><select name="year">${options(CONFIG.YEARS, "I")}</select></div>
      <div class="full muted small">${e.fee > 0 ? "Registration fee: ₹" + e.fee + " (pay at the venue / as told by the organizer)." : "This event is free."}</div>
      <div class="full form-error" id="reg-error"></div>
      <div class="full form-actions"><button type="button" class="btn btn-ghost" data-close>Cancel</button><button class="btn" type="submit">Confirm registration</button></div>
    </form>`);
  $("#reg-form", m).onsubmit = async ev => {
    ev.preventDefault();
    try {
      await API.registerForEvent(id, Object.fromEntries(new FormData(ev.target)));
      closeModal(); toast("Registered successfully! 🎉");
      await refreshMine(); updateBadge();
      onSection(location.hash.slice(1) || "browse");
    } catch (err) { $("#reg-error", m).textContent = err.message; }
  };
}

/* --------------------------------------------------- MY REGISTRATIONS */
async function loadRegistrations() {
  await refreshMine();
  const rows = [...myRegs].sort((a, b) => a.event.date.localeCompare(b.event.date));
  $("#my-regs").innerHTML = rows.length ? `<div class="table-wrap"><table>
      <thead><tr><th>Event</th><th>Date & time</th><th>Venue</th><th>Event status</th><th>Attendance</th><th>Registered on</th><th></th></tr></thead>
      <tbody>${rows.map(r => `<tr>
        <td><b>${esc(r.event.title)}</b><br><span class="badge cat">${esc(r.event.category)}</span></td>
        <td>${fmtDate(r.event.date)}<br><span class="muted small">${fmtTime(r.event.time)}</span></td>
        <td>${esc(r.event.venue)}</td><td>${statusBadge(r.event.status)}</td><td>${attendanceBadge(r.attendance, isHeld(r.event))}</td><td>${fmtDate(r.registeredAt)}</td>
        <td><div class="actions"><button class="btn btn-ghost btn-sm" data-view="${r.event.id}">Details</button>
          ${r.event.status !== "completed" ? `<button class="btn btn-ghost btn-sm" data-cancel="${r.id}">Cancel</button>` : ""}</div></td>
      </tr>`).join("")}</tbody></table></div>`
    : `<div class="card empty">You have not registered for any event yet.<br><br><button class="btn" onclick="showSection('browse')">Browse events</button></div>`;
  bindViewButtons($("#my-regs"));
  $$("[data-cancel]").forEach(b => b.onclick = async () => {
    if (!(await confirmBox("Cancel your registration for this event?", "Cancel registration"))) return;
    await safe(() => API.cancelRegistration(b.dataset.cancel));
    toast("Registration cancelled"); loadRegistrations();
  });
}

/* --------------------------------------------------- NOTIFICATIONS (FR-11) */
async function loadNotices() {
  const list = (await safe(() => API.getNotices())) || [];
  const seen = Number(localStorage.getItem(seenKey) || 0);
  $("#notice-list").innerHTML = noticesHTML(list, { seenAt: seen });
  localStorage.setItem(seenKey, Date.now());     // mark everything as read
  updateBadge(0);
}
async function updateBadge(forced) {
  const dot = $("#notice-dot");
  let n = forced;
  if (n === undefined) {
    const list = (await safe(() => API.getNotices())) || [];
    const seen = Number(localStorage.getItem(seenKey) || 0);
    n = list.filter(x => new Date(x.createdAt).getTime() > seen).length;
  }
  dot.textContent = n; dot.classList.toggle("hidden", !n);
}

/* ====================================================================
   ATTENDANCE, FEEDBACK & CERTIFICATES
   - attendance is marked by the organizer (the student only SEES it)
   - the feedback button and the certificate are shown ONLY when attendance = "present"
   ==================================================================== */
async function loadAttendance() {
  await refreshMine();
  const rows = [...myRegs].sort((a, b) => b.event.date.localeCompare(a.event.date));
  const present = rows.filter(r => r.attendance === "present");
  $("#att-present").textContent = present.length;
  $("#att-absent").textContent = rows.filter(r => r.attendance === "absent").length;
  $("#att-fb").textContent = present.filter(r => r.feedback).length;
  $("#att-certs").textContent = present.filter(r => r.certificate).length;

  $("#att-list").innerHTML = rows.length ? `<div class="table-wrap"><table>
    <thead><tr><th>Event</th><th>Date</th><th>Attendance</th><th>Feedback</th><th>Certificate</th></tr></thead>
    <tbody>${rows.map(r => {
      const isPresent = r.attendance === "present";
      // FEEDBACK cell - only for present students
      const fbCell = !isPresent ? `<span class="muted small">Only for attended events</span>`
        : r.feedback ? `${starsHTML(r.feedback.rating)}<br><button class="btn btn-ghost btn-sm" style="margin-top:6px" data-fb="${r.id}">Edit feedback</button>`
        : `<button class="btn btn-sm" data-fb="${r.id}">⭐ Give feedback</button>`;
      // CERTIFICATE cell - only for present students
      const certCell = !isPresent ? `<span class="muted small">Only for attended events</span>`
        : r.certificate ? `<button class="btn btn-green btn-sm" data-cert="${r.id}">⬇ Download</button><div class="muted small" style="margin-top:4px">${esc(r.certificate.fileName)}</div>`
        : `<span class="muted small">Not uploaded yet<br>(the organizer will upload it)</span>`;
      return `<tr><td><b>${esc(r.event.title)}</b><br><span class="badge cat">${esc(r.event.category)}</span></td>
        <td>${fmtDate(r.event.date)}<br><span class="muted small">${fmtTime(r.event.time)}</span></td>
        <td>${attendanceBadge(r.attendance, isHeld(r.event))}</td><td>${fbCell}</td><td>${certCell}</td></tr>`;
    }).join("")}</tbody></table></div>`
    : `<div class="card empty">You have not registered for any event yet.<br><br><button class="btn" onclick="showSection('browse')">Browse events</button></div>`;

  $$("[data-fb]", $("#att-list")).forEach(b => b.onclick = () => openFeedback(myRegs.find(r => r.id === Number(b.dataset.fb))));
  $$("[data-cert]", $("#att-list")).forEach(b => b.onclick = () => downloadCertificate(b.dataset.cert));
}

/** Feedback window: star rating + comment */
function openFeedback(reg) {
  let rating = reg.feedback ? reg.feedback.rating : 0;
  const m = openModal("Feedback - " + reg.event.title, `
    <form id="fb-form" novalidate>
      <div class="field"><label>Your rating <span class="req">*</span></label>
        <div class="star-input" id="stars">${[1, 2, 3, 4, 5].map(n => `<button type="button" data-v="${n}" aria-label="${n} star">★</button>`).join("")}</div></div>
      <div class="field" style="margin-top:14px"><label>Comments (optional)</label>
        <textarea name="comment" maxlength="500" placeholder="What did you like? What can be improved?">${esc(reg.feedback ? reg.feedback.comment : "")}</textarea></div>
      <div class="form-error" id="fb-error"></div>
      <div class="form-actions"><button type="button" class="btn btn-ghost" data-close>Cancel</button><button class="btn" type="submit">Submit feedback</button></div>
    </form>`);
  const paint = () => $$("#stars button", m).forEach(b => b.classList.toggle("on", Number(b.dataset.v) <= rating));
  $$("#stars button", m).forEach(b => b.onclick = () => { rating = Number(b.dataset.v); paint(); });
  paint();
  $("#fb-form", m).onsubmit = async e => {
    e.preventDefault();
    try {
      await API.submitFeedback(reg.id, { rating, comment: e.target.comment.value });
      closeModal(); toast("Thank you for your feedback!"); loadAttendance();
    } catch (err) { $("#fb-error", m).textContent = err.message; }
  };
}

/* ---------- start the panel (kept at the bottom so everything above is ready) ---------- */
if (user) start();
