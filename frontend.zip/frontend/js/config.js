/* =====================================================================
   config.js  -  settings you may want to change (loaded on every page)
   ===================================================================== */
const CONFIG = {
  APP_NAME: "EventVista",

  // Address of the Java backend. Only used by api.remote.js (see LINKING_GUIDE.md)
  API_BASE: "http://localhost:8080/api",

  // Students who sign up as "Organizer" must enter this code (FR-01: authorized users)
  ORGANIZER_CODE: "ORG2026",

  // Dropdown lists - add / remove items as you like
  CATEGORIES:  ["Technical", "Cultural", "Sports", "Workshop", "Seminar", "Hackathon", "Club Activity", "Other"],
  DEPARTMENTS: ["CSE", "CST", "IT", "AI & DS", "ECE", "EE", "ME", "CE", "Other"],
  YEARS:       ["I", "II", "III", "IV"],

  // Certificate upload: allowed file types and maximum size (KB)
  CERT_ACCEPT: ".pdf,.png,.jpg,.jpeg",
  CERT_MAX_KB: 1400,

  // Labels shown for each event status (FR-13)
  STATUS_LABELS: {
    upcoming:  "Upcoming",
    open:      "Open for Registration",
    closed:    "Registration Closed",
    completed: "Completed"
  }
};

/* Remembers who is logged in (stored in the browser). Used by both API files. */
const Session = {
  KEY: "ev_session",
  get()   { try { return JSON.parse(localStorage.getItem(this.KEY)); } catch (e) { return null; } },
  set(s)  { localStorage.setItem(this.KEY, JSON.stringify(s)); },
  clear() { localStorage.removeItem(this.KEY); }
};
