/* =====================================================================
   common.js  -  helpers shared by ALL panels (student / organizer / admin)
   Needs: config.js and api.local.js (or api.remote.js) loaded first.
   ===================================================================== */

/* ---------- tiny DOM shortcuts ---------- */
const $  = (sel, root = document) => root.querySelector(sel);
const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];

/** Escape text so user input can never inject HTML. ALWAYS use it when printing user text. */
function esc(v) {
  return String(v ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}

/* ---------- formatting ---------- */
function fmtDate(d) {                       // 2026-11-25 -> 25 Nov 2026
  if (!d) return "-";
  const [y, m, day] = d.split("-").map(Number);
  return new Date(y, m - 1, day).toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" });
}
function fmtTime(t) {                       // 14:00 -> 2:00 PM
  if (!t) return "-";
  const [h, m] = t.split(":").map(Number);
  return `${h % 12 || 12}:${String(m).padStart(2, "0")} ${h >= 12 ? "PM" : "AM"}`;
}
function fmtStamp(iso) {                    // 2026-11-10T05:00:00Z -> 10 Nov 2026, 10:30 AM
  return new Date(iso).toLocaleString("en-IN", { day: "numeric", month: "short", year: "numeric", hour: "numeric", minute: "2-digit" });
}
const fee = n => (n > 0 ? "₹" + n : "Free");
const statusBadge = s => `<span class="badge ${esc(s)}">${esc(CONFIG.STATUS_LABELS[s] || s)}</span>`;
const options = (list, selected, withAll) =>
  (withAll ? `<option value="all">${withAll}</option>` : "") +
  list.map(x => `<option value="${esc(x)}" ${x === selected ? "selected" : ""}>${esc(x)}</option>`).join("");

/* ---------- toast message (small popup bottom-right) ---------- */
function toast(msg, type = "ok") {
  let root = $("#toast-root");
  if (!root) { root = document.createElement("div"); root.id = "toast-root"; document.body.appendChild(root); }
  const t = document.createElement("div");
  t.className = "toast " + (type === "error" ? "error" : "");
  t.textContent = msg;
  root.appendChild(t);
  setTimeout(() => t.remove(), 3500);
}

/** Run an async action; show an error toast if it fails. Returns result or undefined. */
async function safe(fn) {
  try { return await fn(); } catch (e) { toast(e.message, "error"); }
}

/* ---------- modal (popup window) ---------- */
function openModal(title, html, opts = {}) {
  closeModal();
  const o = document.createElement("div");
  o.className = "modal-overlay"; o.id = "modal-overlay";
  o.innerHTML = `<div class="modal ${opts.wide ? "modal-wide" : ""}" role="dialog" aria-modal="true">
      <div class="modal-head"><h3>${esc(title)}</h3><button class="icon-btn" data-close aria-label="Close">✕</button></div>
      <div class="modal-body">${html}</div></div>`;
  o.addEventListener("mousedown", e => { if (e.target === o || e.target.closest("[data-close]")) closeModal(); });
  document.body.appendChild(o);
  document.body.style.overflow = "hidden";
  return $(".modal", o);
}
function closeModal() {
  const o = $("#modal-overlay");
  if (o) o.remove();
  document.body.style.overflow = "";
}
document.addEventListener("keydown", e => { if (e.key === "Escape") closeModal(); });

function confirmBox(message, okText = "Yes, continue") {
  return new Promise(resolve => {
    const m = openModal("Please confirm", `<p>${esc(message)}</p>
      <div class="form-actions"><button class="btn btn-ghost" data-no>Cancel</button><button class="btn btn-red" data-yes>${esc(okText)}</button></div>`);
    $("[data-no]", m).onclick = () => { closeModal(); resolve(false); };
    $("[data-yes]", m).onclick = () => { closeModal(); resolve(true); };
  });
}

/* ---------- panel shell: login guard, sidebar, top bar ---------- */
/**
 * Call at the start of every panel page.
 *  role = "student" | "organizer" | "admin"
 * If the visitor is not logged in (or is in the wrong panel) they are sent back to index.html.
 */
function guard(role) {
  const s = Session.get();
  if (!s || !s.user || s.user.role !== role) { location.replace("index.html"); return null; }
  return s.user;
}

function initShell(user, onSection) {
  // fill user info
  $$("[data-user-name]").forEach(e => e.textContent = user.name);
  $$("[data-user-role]").forEach(e => e.textContent = user.role);
  $$("[data-user-initial]").forEach(e => e.textContent = user.name.trim()[0].toUpperCase());

  // logout
  $$("[data-logout]").forEach(b => b.onclick = async () => { await API.logout(); location.href = "index.html"; });

  // mobile sidebar
  const sidebar = $(".sidebar"), scrim = $(".scrim");
  const setOpen = open => { sidebar.classList.toggle("open", open); scrim.classList.toggle("show", open); };
  $(".menu-btn").onclick = () => setOpen(true);
  scrim.onclick = () => setOpen(false);

  // switching sections (sidebar links have data-section="name" -> <section id="sec-name">)
  function show(name) {
    if (!$("#sec-" + name)) name = $$(".nav-link[data-section]")[0].dataset.section;
    $$(".panel-section").forEach(s => s.classList.toggle("active", s.id === "sec-" + name));
    $$(".nav-link[data-section]").forEach(l => l.classList.toggle("active", l.dataset.section === name));
    history.replaceState(null, "", "#" + name);
    setOpen(false);
    window.scrollTo(0, 0);
    if (onSection) onSection(name);
  }
  $$(".nav-link[data-section]").forEach(l => l.onclick = () => show(l.dataset.section));
  window.showSection = show;
  show(location.hash.slice(1) || $$(".nav-link[data-section]")[0].dataset.section);
}

/* ---------- event card (used by student browse + home) ---------- */
function eventCardHTML(e, buttons = "") {
  const pct = Math.min(100, Math.round((e.registered / e.capacity) * 100));
  const cls = pct >= 100 ? "full" : pct >= 80 ? "warn" : "";
  return `<article class="card event-card">
      <div class="top"><h3>${esc(e.title)}</h3>${statusBadge(e.status)}</div>
      <div><span class="badge cat">${esc(e.category)}</span></div>
      <div class="meta">
        <span>◷ ${fmtDate(e.date)} · ${fmtTime(e.time)}</span>
        <span>⌖  ${esc(e.venue)}</span>
        <span>Fee: ${fee(e.fee)}</span>
      </div>
      <div class="seats"><div class="progress ${cls}"><span style="width:${pct}%"></span></div>${e.registered} / ${e.capacity} seats filled</div>
      <div class="foot">${buttons}</div>
    </article>`;
}

/* ---------- notifications list ---------- */
function noticesHTML(list, { canDelete = false, seenAt = 0 } = {}) {
  if (!list.length) return `<div class="empty">No announcements yet.</div>`;
  return list.map(n => `<div class="notice ${new Date(n.createdAt).getTime() > seenAt ? "new" : ""}">
      <div class="n-ico">♧</div>
      <div class="grow"><h4>${esc(n.title)}</h4><p>${esc(n.message)}</p>
        <div class="when">${fmtStamp(n.createdAt)} · by ${esc(n.author || "System")}</div></div>
      ${canDelete ? `<button class="btn btn-ghost btn-sm" data-del-notice="${n.id}">Delete</button>` : ""}
    </div>`).join("");
}

/* ---------- CSV download (participants export) ---------- */
function downloadCSV(filename, rows) {
  const csv = rows.map(r => r.map(c => '"' + String(c ?? "").replace(/"/g, '""') + '"').join(",")).join("\n");
  const a = document.createElement("a");
  a.href = URL.createObjectURL(new Blob([csv], { type: "text/csv" }));
  a.download = filename; a.click();
  URL.revokeObjectURL(a.href);
}

/* =====================================================================
   EVENT FORM  (FR-03 create + FR-04 edit)  - used by organizer AND admin
   openEventForm(null, cb)  -> create new      openEventForm(event, cb) -> edit
   ===================================================================== */
function openEventForm(ev, onSaved) {
  const e = ev || { category: CONFIG.CATEGORIES[0], capacity: 100, fee: 0 };
  const m = openModal(ev ? "Edit event" : "Create new event", `
    <form id="event-form" class="form-grid" novalidate>
      <div class="field full"><label>Event title <span class="req">*</span></label>
        <input name="title" value="${esc(e.title)}" placeholder="e.g. CodeSprint Hackathon" required></div>
      <div class="field"><label>Category <span class="req">*</span></label>
        <select name="category">${options(CONFIG.CATEGORIES, e.category)}</select></div>
      <div class="field"><label>Venue <span class="req">*</span></label>
        <input name="venue" value="${esc(e.venue)}" placeholder="e.g. Seminar Hall 2"></div>
      <div class="field full"><label>Description <span class="req">*</span></label>
        <textarea name="description" placeholder="What is this event about?">${esc(e.description)}</textarea></div>
      <div class="field"><label>Event date <span class="req">*</span></label><input type="date" name="date" value="${esc(e.date)}"></div>
      <div class="field"><label>Event time <span class="req">*</span></label><input type="time" name="time" value="${esc(e.time)}"></div>
      <div class="field"><label>Registration opens <span class="req">*</span></label><input type="date" name="regOpen" value="${esc(e.regOpen)}"></div>
      <div class="field"><label>Registration deadline <span class="req">*</span></label><input type="date" name="regDeadline" value="${esc(e.regDeadline)}"></div>
      <div class="field"><label>Maximum participants <span class="req">*</span></label><input type="number" min="1" name="capacity" value="${esc(e.capacity)}"></div>
      <div class="field"><label>Registration fee (₹, 0 = free)</label><input type="number" min="0" name="fee" value="${esc(e.fee)}"></div>
      <div class="field full"><label>Contact (email / phone)</label><input name="contact" value="${esc(e.contact)}" placeholder="organizer@college.edu"></div>
      <div class="full form-error" id="event-error"></div>
      <div class="full form-actions">
        <button type="button" class="btn btn-ghost" data-close>Cancel</button>
        <button type="submit" class="btn">${ev ? "Save changes" : "Create event"}</button>
      </div>
    </form>`, { wide: true });

  $("#event-form", m).onsubmit = async evt => {
    evt.preventDefault();
    const data = Object.fromEntries(new FormData(evt.target));
    try {
      const saved = ev ? await API.updateEvent(ev.id, data) : await API.createEvent(data);
      closeModal();
      toast(ev ? "Event updated" : "Event created");
      if (onSaved) onSaved(saved);
    } catch (err) { $("#event-error", m).textContent = err.message; }
  };
}

/* =====================================================================
   PARTICIPANTS  (FR-09 records + FR-10 manage) - organizer AND admin
   ===================================================================== */
async function openParticipants(ev, onChanged) {
  const m = openModal("Participants - " + ev.title, `<div class="empty">Loading...</div>`, { wide: true });
  async function render() {
    const list = await API.eventRegistrations(ev.id);
    $(".modal-body", m).innerHTML = `
      <div class="section-head" style="margin-bottom:14px">
        <p>${list.length} registered of ${ev.capacity} seats</p>
        <div style="display:flex;gap:8px;flex-wrap:wrap">
          <input class="search-input" id="p-search" placeholder="Search participants..." style="width:220px">
          <button class="btn btn-ghost btn-sm" id="p-export" ${list.length ? "" : "disabled"}>⬇ Export CSV</button>
        </div>
      </div>
      <div class="table-wrap"><table>
        <thead><tr><th>#</th><th>Name</th><th>Enrollment</th><th>Dept / Year</th><th>Attendance</th><th>Email</th><th>Phone</th><th>Registered</th><th></th></tr></thead>
        <tbody id="p-body">${list.map((r, i) => `<tr data-text="${esc((r.name + r.email + r.enrollment).toLowerCase())}">
          <td>${i + 1}</td><td>${esc(r.name)}</td><td>${esc(r.enrollment) || "-"}</td>
          <td>${esc(r.department) || "-"} / ${esc(r.year) || "-"}</td><td>${attendanceBadge(r.attendance, isHeld(ev))}</td><td>${esc(r.email)}</td><td>${esc(r.phone)}</td>
          <td>${fmtDate(r.registeredAt)}</td>
          <td><button class="btn btn-ghost btn-sm" data-remove="${r.id}">Remove</button></td></tr>`).join("")}
        </tbody></table>${list.length ? "" : `<div class="empty">Nobody has registered yet.</div>`}</div>`;

    $("#p-search", m).oninput = e => {
      const q = e.target.value.toLowerCase();
      $$("#p-body tr", m).forEach(tr => tr.classList.toggle("hidden", !tr.dataset.text.includes(q)));
    };
    $("#p-export", m).onclick = () => downloadCSV(ev.title.replace(/\W+/g, "_") + "_participants.csv",
      [["Name", "Enrollment", "Department", "Year", "Attendance", "Email", "Phone", "Registered on"],
       ...list.map(r => [r.name, r.enrollment, r.department, r.year, r.attendance || "not marked", r.email, r.phone, r.registeredAt])]);
    $$("[data-remove]", m).forEach(b => b.onclick = async () => {
      // confirmBox replaces this window, so we reopen the participants list afterwards
      if (!(await confirmBox("Remove this participant from the event?", "Remove"))) return openParticipants(ev, onChanged);
      await safe(() => API.cancelRegistration(b.dataset.remove));
      toast("Participant removed");
      if (onChanged) onChanged();
      openParticipants(ev, onChanged);
    });
  }
  await safe(render);
}

/* =====================================================================
   ANNOUNCEMENTS (FR-11) - post form + list. Used by organizer AND admin
   ===================================================================== */
async function initAnnouncements(rootId, listId, formId, eventsLoader) {
  const form = $("#" + formId), listBox = $("#" + listId);
  async function refreshList() {
    const list = await API.getNotices();
    listBox.innerHTML = noticesHTML(list, { canDelete: true });
    $$("[data-del-notice]", listBox).forEach(b => b.onclick = async () => {
      if (!(await confirmBox("Delete this announcement?", "Delete"))) return;
      await safe(() => API.deleteNotice(b.dataset.delNotice));
      toast("Announcement deleted"); refreshList();
    });
  }
  // fill the optional "related event" dropdown
  const evs = await eventsLoader();
  $("select[name=eventId]", form).innerHTML = `<option value="">- General announcement -</option>` +
    evs.map(e => `<option value="${e.id}">${esc(e.title)}</option>`).join("");

  form.onsubmit = async e => {
    e.preventDefault();
    const data = Object.fromEntries(new FormData(form));
    try { await API.postNotice(data); form.reset(); toast("Announcement published"); refreshList(); }
    catch (err) { $(".form-error", form).textContent = err.message; }
  };
  await refreshList();
}

/* =====================================================================
   ATTENDANCE / FEEDBACK / CERTIFICATE helpers (student + organizer + admin)
   ===================================================================== */
const todayStr = () => { const d = new Date(), p = n => String(n).padStart(2, "0"); return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`; };
/** An event can have attendance once its day has come (same rule as the backend). */
const isHeld = ev => ev.date <= todayStr();

/** Present / Absent / Not marked badge */
function attendanceBadge(a, held = true) {
  if (a === "present") return `<span class="badge present">✔ Present</span>`;
  if (a === "absent")  return `<span class="badge absent">✖ Absent</span>`;
  return `<span class="badge pending">${held ? "Not marked yet" : "Event not held yet"}</span>`;
}

/** ★★★★☆ */
const starsHTML = n => `<span class="stars" title="${n} / 5">${"★".repeat(n)}<span class="off">${"★".repeat(5 - n)}</span></span>`;

/** Ask the user for a certificate file, check it, and give back { fileName, fileType, data } */
function pickCertificateFile(done) {
  const input = document.createElement("input");
  input.type = "file"; input.accept = CONFIG.CERT_ACCEPT;
  input.onchange = () => {
    const f = input.files[0];
    if (!f) return;
    if (!["application/pdf", "image/png", "image/jpeg"].includes(f.type)) return toast("Only PDF, PNG or JPG files are allowed", "error");
    if (f.size > CONFIG.CERT_MAX_KB * 1024) return toast("File is too big (max " + CONFIG.CERT_MAX_KB + " KB)", "error");
    const reader = new FileReader();
    reader.onload = () => done({ fileName: f.name, fileType: f.type, data: reader.result });   // data = base64 data-URL
    reader.readAsDataURL(f);
  };
  input.click();
}

/** Download a certificate file */
async function downloadCertificate(regId) {
  const c = await safe(() => API.getCertificate(regId));
  if (!c) return;
  const a = document.createElement("a");
  a.href = c.data; a.download = c.fileName;
  document.body.appendChild(a); a.click(); a.remove();
}
