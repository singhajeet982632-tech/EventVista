/* =====================================================================
   api.remote.js  -  talks to the JAVA BACKEND using fetch()
   ---------------------------------------------------------------------
   NOT USED YET (the pages load api.local.js).
   To connect frontend <-> backend, follow LINKING_GUIDE.md:
   in every HTML page change  <script src="js/api.local.js">
                        to    <script src="js/api.remote.js">
   Every function name and result is identical to api.local.js, so no
   other file needs to change.
   ===================================================================== */
const API = (() => {

  /** One helper that sends every request to the backend. */
  async function call(method, path, body) {
    const headers = { "Content-Type": "application/json" };
    const s = Session.get();
    if (s && s.token) headers["Authorization"] = "Bearer " + s.token;   // proves who we are

    let res;
    try {
      res = await fetch(CONFIG.API_BASE + path, { method, headers, body: body ? JSON.stringify(body) : undefined });
    } catch (e) {
      throw new Error("Cannot reach the server. Is the Java backend running on " + CONFIG.API_BASE + " ?");
    }
    let data = {};
    try { data = await res.json(); } catch (e) { /* empty body */ }
    if (!res.ok) {
      // token expired / server restarted -> ask the user to log in again
      if (res.status === 401 && s) { Session.clear(); }
      throw new Error(data.error || "Request failed (" + res.status + ")");
    }
    return data;
  }

  /** Build "?a=1&b=2" from an object, skipping empty values. */
  const qs = p => {
    const e = Object.entries(p || {}).filter(([, v]) => v !== "" && v != null && v !== false);
    return e.length ? "?" + e.map(([k, v]) => encodeURIComponent(k) + "=" + encodeURIComponent(v)).join("&") : "";
  };

  return {
    mode: "remote",   // tells the pages which API file is active
    /* AUTH */
    async register(b) { const r = await call("POST", "/auth/register", b); Session.set(r); return r; },
    async login(email, password) { const r = await call("POST", "/auth/login", { email, password }); Session.set(r); return r; },
    async logout() { try { await call("POST", "/auth/logout"); } catch (e) {} Session.clear(); return { ok: true }; },
    me() { return call("GET", "/auth/me"); },

    /* EVENTS */
    getEvents(p) { return call("GET", "/events" + qs(p)); },
    getEvent(id) { return call("GET", "/events/" + id); },
    createEvent(b) { return call("POST", "/events", b); },
    updateEvent(id, b) { return call("PUT", "/events/" + id, b); },
    deleteEvent(id) { return call("DELETE", "/events/" + id); },

    /* REGISTRATIONS */
    registerForEvent(id, b) { return call("POST", "/events/" + id + "/register", b); },
    cancelRegistration(id) { return call("DELETE", "/registrations/" + id); },
    myRegistrations() { return call("GET", "/my/registrations"); },
    eventRegistrations(id) { return call("GET", "/events/" + id + "/registrations"); },

    /* NOTIFICATIONS */
    getNotices() { return call("GET", "/notifications"); },
    postNotice(b) { return call("POST", "/notifications", b); },
    deleteNotice(id) { return call("DELETE", "/notifications/" + id); },

    /* ATTENDANCE / FEEDBACK / CERTIFICATES */
    markAttendance(regId, status) { return call("PUT", "/registrations/" + regId + "/attendance", { status }); },
    markAllAttendance(eventId, status) { return call("PUT", "/events/" + eventId + "/attendance", { status }); },
    submitFeedback(regId, b) { return call("POST", "/registrations/" + regId + "/feedback", b); },
    eventFeedback(eventId) { return call("GET", "/events/" + eventId + "/feedback"); },
    uploadCertificate(regId, b) { return call("POST", "/registrations/" + regId + "/certificate", b); },
    deleteCertificate(regId) { return call("DELETE", "/registrations/" + regId + "/certificate"); },
    getCertificate(regId) { return call("GET", "/registrations/" + regId + "/certificate"); },

    /* ADMIN */
    adminStats() { return call("GET", "/admin/stats"); },
    adminUsers() { return call("GET", "/admin/users"); },
    adminUpdateUser(id, b) { return call("PUT", "/admin/users/" + id, b); },
    adminDeleteUser(id) { return call("DELETE", "/admin/users/" + id); },
    adminRegistrations() { return call("GET", "/admin/registrations"); },

    resetDemo() { Session.clear(); }
  };
})();
