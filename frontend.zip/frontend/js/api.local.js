/* =====================================================================
   api.local.js  -  "fake backend" that runs INSIDE the browser
   ---------------------------------------------------------------------
   Stores everything in localStorage so the website works on its own
   (no server needed). It offers exactly the same functions as the Java
   backend, so later you only swap this file for api.remote.js.
   (Passwords here are only lightly encoded - demo only. The Java
    backend uses proper salted SHA-256 hashing.)
   ===================================================================== */
const API = (() => {
  const DB_KEY = "ev_local_db_v1";

  // ------------------------------------------------------------ helpers
  const pad = n => String(n).padStart(2, "0");
  const dateStr = d => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
  const today = () => dateStr(new Date());
  const inDays = n => { const d = new Date(); d.setDate(d.getDate() + n); return dateStr(d); };
  const fail = msg => { throw new Error(msg); };
  const enc = s => btoa(unescape(encodeURIComponent("ev::" + s)));
  const str = v => (v == null ? "" : String(v).trim());

  // ----------------------------------------------------------- database
  let db = null;
  function load() {
    if (db) return db;
    try { db = JSON.parse(localStorage.getItem(DB_KEY)); } catch (e) { db = null; }
    if (!db) { db = seed(); save(); }
    return db;
  }
  function save() { localStorage.setItem(DB_KEY, JSON.stringify(db)); }
  const nextId = () => { const d = load(); d.nextId += 1; return d.nextId; };

  /** Demo data. Edit freely, then clear browser storage (or call API.resetDemo()) to reload it. */
  function seed() {
    const d = { nextId: 1000, users: [], events: [], registrations: [], notices: [] };
    const mkUser = (name, email, pass, role, enrollment, department) =>
      ({ id: ++d.nextId, name, email, pass: enc(pass), role, enrollment, department, status: "active", createdAt: today() });
    d.users.push(mkUser("Admin User", "admin@eventvista.com", "admin123", "admin", "", "Administration"));
    const org = mkUser("Dr. Rakesh Verma", "organizer@eventvista.com", "org123", "organizer", "", "CSE");
    d.users.push(org);
    const stu = mkUser("Ajeet Singh", "student@eventvista.com", "student123", "student", "0101CS261001", "CSE");
    d.users.push(stu);
    const riya = mkUser("Riya Sharma", "riya@eventvista.com", "student123", "student", "0101CS261014", "CSE"); d.users.push(riya);
    const karan = mkUser("Karan Mehta", "karan@eventvista.com", "student123", "student", "0101IT261022", "IT"); d.users.push(karan);

    const ev = (title, category, description, dayOffset, time, venue, capacity, openOff, deadlineOff, fee) =>
      d.events.push({
        id: ++d.nextId, title, category, description, date: inDays(dayOffset), time, venue, capacity,
        regOpen: inDays(openOff), regDeadline: inDays(deadlineOff), fee, contact: org.email,
        organizerId: org.id, organizerName: org.name, createdAt: today()
      });
    ev("CodeSprint Hackathon", "Hackathon", "24-hour team hackathon. Build something useful for campus life and win prizes.", 25, "10:00", "Innovation Lab, Block C", 100, -10, 12, 200);
    ev("Web Development Workshop", "Workshop", "Hands-on workshop on HTML, CSS and JavaScript for beginners.", 8, "14:00", "Seminar Hall 2", 60, -3, 5, 0);
    ev("Annual Cultural Fest - Rang", "Cultural", "Music, dance, drama and food stalls. Register early for performances!", 40, "17:00", "Main Auditorium", 300, 15, 35, 50);
    ev("Inter-College Cricket Cup", "Sports", "Knockout cricket tournament. Team of 11 + 2 substitutes.", 18, "09:00", "College Ground", 16, -5, -1, 500);
    ev("AI & Machine Learning Seminar", "Seminar", "Guest lecture on careers and research in AI by industry experts.", -6, "11:00", "Conference Hall", 150, -20, -8, 0);
    ev("Open Source Club Meetup", "Club Activity", "Learn how to contribute to open source and make your first pull request.", 12, "16:00", "Library Hall", 40, -2, 9, 0);

    const web = d.events[1];
    d.registrations.push({ id: ++d.nextId, eventId: web.id, userId: stu.id, name: stu.name, email: stu.email,
      enrollment: stu.enrollment, department: stu.department, phone: "9876543210", year: "I", registeredAt: today() });
    // The AI seminar is already over, so attendance / feedback / certificates can be tried right away.
    // attendance: "" (not marked) | "present" | "absent"     fb = feedback     cert = certificate file
    const sem = d.events[4];
    const semReg = (u, phone, year, extra) => d.registrations.push({ id: ++d.nextId, eventId: sem.id, userId: u.id, name: u.name,
      email: u.email, enrollment: u.enrollment, department: u.department, phone, year, registeredAt: today(), ...extra });
    semReg(stu, "9876543210", "I", { attendance: "present" });
    semReg(riya, "9811122233", "I", { attendance: "present", fb: { rating: 4, comment: "Very informative session, loved the career tips.", submittedAt: new Date().toISOString() } });
    semReg(karan, "9822233344", "II", {});
    d.notices.push({ id: ++d.nextId, title: "Welcome to EventVista!", message: "Browse events, register online and stay updated with announcements.", createdAt: new Date().toISOString(), userId: null, eventId: null, author: "System" });
    d.notices.push({ id: ++d.nextId, title: "Semester break", message: "Semester break is from Nov 10 to Nov 13. Plan your events accordingly.", createdAt: new Date().toISOString(), userId: null, eventId: null, author: "Admin User" });
    return d;
  }

  // ------------------------------------------------------------ session
  function current() {
    const s = Session.get();
    if (!s) return null;
    return load().users.find(u => u.id === s.user.id) || null;
  }
  function requireLogin() {
    const u = current();
    if (!u) fail("Please log in first");
    if (u.status === "blocked") fail("Your account is blocked");
    return u;
  }
  function requireRole(...roles) {
    const u = requireLogin();
    if (!roles.includes(u.role)) fail("You are not allowed to do this");
    return u;
  }
  const publicUser = u => { const { pass, ...rest } = u; return rest; };

  /** Shape of a registration sent to the pages (same as the Java backend). The certificate FILE is not included. */
  const rv = r => {
    const { fb, cert, ...rest } = r;
    return { ...rest, attendance: r.attendance || "",
      feedback: fb || null,
      certificate: cert ? { fileName: cert.fileName, fileType: cert.fileType, uploadedAt: cert.uploadedAt } : null };
  };

  // ---- attendance / certificate rules (same as AttendanceHandler.java) ----
  const ALLOW_BEFORE_EVENT_DAY = false;                    // true = allow marking attendance before the event day
  const CERT_TYPES = ["application/pdf", "image/png", "image/jpeg"];
  const MAX_CERT_CHARS = 2000000;                          // browser storage is small, so the limit is lower than the backend
  function requireHeld(e) {
    if (!ALLOW_BEFORE_EVENT_DAY && today() < e.date) fail("This can be done only on or after the event day (" + e.date + ")");
  }
  function findReg(id) { const r = load().registrations.find(x => x.id === Number(id)); if (!r) fail("Registration not found"); return r; }
  /** Change attendance of one student. Leaving "present" removes the feedback + certificate. */
  function setAttendance(r, e, status, author) {
    if (!["present", "absent", ""].includes(status)) fail("Status must be present, absent or empty");
    const was = r.attendance === "present";
    r.attendance = status;
    if (was && status !== "present") { delete r.fb; delete r.cert; }
    if (!was && status === "present")
      addNotice("Attendance marked: Present", `You were marked present for "${e.title}". You can now give feedback and download your certificate when it is uploaded.`, r.userId, e.id, author);
  }

  // ------------------------------------------------------- event helpers
  const countFor = id => load().registrations.filter(r => r.eventId === id).length;

  /** FR-13 : same rules as the Java backend (Models.Event.status) */
  function statusOf(e, count) {
    const t = today();
    if (t > e.date) return "completed";
    if (t < e.regOpen) return "upcoming";
    if (t > e.regDeadline || count >= e.capacity) return "closed";
    return "open";
  }
  const view = e => { const c = countFor(e.id); return { ...e, registered: c, status: statusOf(e, c) }; };

  function ownEvent(user, id) {
    const e = load().events.find(x => x.id === Number(id));
    if (!e) fail("Event not found");
    if (user.role !== "admin" && e.organizerId !== user.id) fail("You can only manage your own events");
    return e;
  }

  function validateEvent(b) {
    const title = str(b.title), venue = str(b.venue);
    if (title.length < 3) fail("Title must be at least 3 characters");
    if (!venue) fail("Venue is required");
    if (str(b.description).length < 10) fail("Description must be at least 10 characters");
    if (Number(b.capacity) < 1) fail("Capacity must be at least 1");
    if (!b.date || !b.regOpen || !b.regDeadline) fail("Please fill all dates correctly");
    if (!/^\d{2}:\d{2}$/.test(str(b.time))) fail("Please enter the event time");
    if (b.regOpen > b.regDeadline) fail("Registration start must be before the deadline");
    if (b.regDeadline > b.date) fail("Registration deadline cannot be after the event date");
    return {
      title, venue, category: str(b.category) || "Other", description: str(b.description),
      date: b.date, time: str(b.time), capacity: Math.round(Number(b.capacity)),
      regOpen: b.regOpen, regDeadline: b.regDeadline, fee: Math.max(0, Math.round(Number(b.fee) || 0)),
      contact: str(b.contact)
    };
  }

  function addNotice(title, message, userId, eventId, author) {
    load().notices.push({ id: nextId(), title, message, createdAt: new Date().toISOString(), userId: userId || null, eventId: eventId || null, author });
    save();
  }

  // =================================================================== PUBLIC API
  return {
    mode: "local",   // tells the pages which API file is active
    /* ------------------------------ AUTH (FR-01, FR-02) ------------------------------ */
    async register(b) {
      const name = str(b.name), email = str(b.email).toLowerCase(), password = str(b.password);
      let role = str(b.role) || "student";
      if (name.length < 2) fail("Please enter your full name");
      if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) fail("Enter a valid email address");
      if (password.length < 6) fail("Password must be at least 6 characters");
      if (load().users.some(u => u.email === email)) fail("This email is already registered");
      if (!["student", "organizer"].includes(role)) fail("Role must be student or organizer");
      if (role === "organizer" && str(b.orgCode) !== CONFIG.ORGANIZER_CODE) fail("Invalid organizer access code");
      const u = { id: nextId(), name, email, pass: enc(password), role, enrollment: str(b.enrollment), department: str(b.department), status: "active", createdAt: today() };
      load().users.push(u); save();
      Session.set({ token: "local-" + u.id, user: publicUser(u) });
      return { token: "local-" + u.id, user: publicUser(u) };
    },
    async login(email, password) {
      const u = load().users.find(x => x.email === str(email).toLowerCase());
      if (!u || u.pass !== enc(str(password))) fail("Incorrect email or password");
      if (u.status === "blocked") fail("Your account is blocked. Contact the administrator.");
      Session.set({ token: "local-" + u.id, user: publicUser(u) });
      return { token: "local-" + u.id, user: publicUser(u) };
    },
    async logout() { Session.clear(); return { ok: true }; },
    async me() { return publicUser(requireLogin()); },

    /* ------------------------------ EVENTS (FR-03 .. FR-07, FR-13) ------------------------------ */
    // params: { search, category, status, mine }
    async getEvents(p = {}) {
      let list = load().events.map(view);
      if (p.mine) { const me = requireRole("organizer", "admin"); list = list.filter(e => e.organizerId === me.id); }
      if (p.category && p.category !== "all") list = list.filter(e => e.category.toLowerCase() === p.category.toLowerCase());
      if (p.status && p.status !== "all") list = list.filter(e => e.status === p.status);
      if (p.search) {   // FR-06
        const q = p.search.toLowerCase();
        list = list.filter(e => (e.title + " " + e.description + " " + e.category + " " + e.venue).toLowerCase().includes(q));
      }
      return list.sort((a, b) => a.date.localeCompare(b.date));
    },
    async getEvent(id) {
      const e = load().events.find(x => x.id === Number(id));
      if (!e) fail("Event not found");
      return view(e);
    },
    async createEvent(b) {
      const u = requireRole("organizer", "admin");
      const e = { id: nextId(), ...validateEvent(b), organizerId: u.id, organizerName: u.name, createdAt: today() };
      load().events.push(e); save();
      addNotice("New event: " + e.title, `${e.category} event on ${e.date} at ${e.venue}. Registration closes ${e.regDeadline}.`, null, e.id, u.name);
      return view(e);
    },
    async updateEvent(id, b) {
      const u = requireRole("organizer", "admin");
      const e = ownEvent(u, id);
      Object.assign(e, validateEvent(b)); save();
      addNotice("Event updated: " + e.title, "Details of this event were updated. Please check date, time and venue.", null, e.id, u.name);
      return view(e);
    },
    async deleteEvent(id) {
      const u = requireRole("organizer", "admin");
      const e = ownEvent(u, id);
      const d = load();
      d.events = d.events.filter(x => x.id !== e.id);
      d.registrations = d.registrations.filter(r => r.eventId !== e.id);
      save();
      addNotice("Event cancelled: " + e.title, "This event has been removed by the organizer.", null, null, u.name);
      return { ok: true };
    },

    /* ------------------------------ REGISTRATIONS (FR-08, FR-09, FR-10) ------------------------------ */
    async registerForEvent(eventId, b) {
      const u = requireRole("student");
      const e = load().events.find(x => x.id === Number(eventId));
      if (!e) fail("Event not found");
      const count = countFor(e.id), status = statusOf(e, count);
      if (status === "upcoming") fail("Registration has not opened yet");
      if (status === "completed") fail("This event is already over");
      if (status === "closed") fail(count >= e.capacity ? "Sorry, the event is full" : "Registration is closed");
      if (load().registrations.some(r => r.eventId === e.id && r.userId === u.id)) fail("You are already registered for this event");
      if (!/^[0-9+\- ]{7,15}$/.test(str(b.phone))) fail("Enter a valid phone number");
      const r = { id: nextId(), eventId: e.id, userId: u.id, name: str(b.name) || u.name, email: str(b.email) || u.email,
        enrollment: str(b.enrollment), department: str(b.department), phone: str(b.phone), year: str(b.year), registeredAt: today() };
      load().registrations.push(r); save();
      addNotice("Registration confirmed", `You are registered for "${e.title}" on ${e.date}.`, u.id, e.id, "System");
      return rv(r);
    },
    async cancelRegistration(regId) {
      const u = requireLogin();
      const d = load();
      const r = d.registrations.find(x => x.id === Number(regId));
      if (!r) fail("Registration not found");
      const ev = d.events.find(x => x.id === r.eventId);
      if (!(u.role === "admin" || r.userId === u.id || (ev && ev.organizerId === u.id))) fail("You are not allowed to do this");
      d.registrations = d.registrations.filter(x => x.id !== r.id); save();
      return { ok: true };
    },
    async myRegistrations() {
      const u = requireLogin();
      const d = load();
      return d.registrations.filter(r => r.userId === u.id)
        .map(r => ({ ...rv(r), event: d.events.find(e => e.id === r.eventId) })).filter(r => r.event)
        .map(r => ({ ...r, event: view(r.event) }));
    },
    async eventRegistrations(eventId) {
      const u = requireRole("organizer", "admin");
      ownEvent(u, eventId);
      return load().registrations.filter(r => r.eventId === Number(eventId)).map(rv);
    },

    /* ------------------------------ NOTIFICATIONS (FR-11) ------------------------------ */
    async getNotices() {
      const u = requireLogin();
      return load().notices.filter(n => n.userId === null || n.userId === u.id || u.role === "admin")
        .sort((a, b) => b.createdAt.localeCompare(a.createdAt));
    },
    async postNotice(b) {
      const u = requireRole("organizer", "admin");
      if (str(b.title).length < 3 || str(b.message).length < 3) fail("Title and message are required");
      const n = { id: nextId(), title: str(b.title), message: str(b.message), createdAt: new Date().toISOString(), userId: null, eventId: b.eventId ? Number(b.eventId) : null, author: u.name };
      load().notices.push(n); save();
      return n;
    },
    async deleteNotice(id) {
      const u = requireRole("organizer", "admin");
      const d = load();
      const n = d.notices.find(x => x.id === Number(id));
      if (!n) fail("Notice not found");
      if (u.role !== "admin" && n.author !== u.name) fail("You can delete only your own announcements");
      d.notices = d.notices.filter(x => x.id !== n.id); save();
      return { ok: true };
    },

    /* ------------------------------ ADMIN (FR-12) ------------------------------ */
    async adminStats() {
      requireRole("admin");
      const d = load();
      const count = (arr, f) => arr.reduce((m, x) => { const k = f(x); m[k] = (m[k] || 0) + 1; return m; }, {});
      return {
        users: d.users.length, events: d.events.length, registrations: d.registrations.length, notices: d.notices.length,
        roles: count(d.users, u => u.role), categories: count(d.events, e => e.category),
        statuses: count(d.events, e => statusOf(e, countFor(e.id)))
      };
    },
    async adminUsers() { requireRole("admin"); return load().users.map(publicUser); },
    async adminUpdateUser(id, b) {
      const me = requireRole("admin");
      const t = load().users.find(u => u.id === Number(id));
      if (!t) fail("User not found");
      if (t.id === me.id) fail("You cannot change or delete your own account here");
      if (b.role) { if (!["student", "organizer", "admin"].includes(b.role)) fail("Invalid role"); t.role = b.role; }
      if (b.status) { if (!["active", "blocked"].includes(b.status)) fail("Invalid status"); t.status = b.status; }
      save();
      return publicUser(t);
    },
    async adminDeleteUser(id) {
      const me = requireRole("admin");
      const d = load();
      const t = d.users.find(u => u.id === Number(id));
      if (!t) fail("User not found");
      if (t.id === me.id) fail("You cannot change or delete your own account here");
      d.users = d.users.filter(u => u.id !== t.id);
      d.registrations = d.registrations.filter(r => r.userId !== t.id);
      save();
      return { ok: true };
    },
    async adminRegistrations() {
      requireRole("admin");
      const d = load();
      return d.registrations.map(r => ({ ...rv(r), eventTitle: (d.events.find(e => e.id === r.eventId) || {}).title || "(deleted)" }));
    },

    /* ------------------------------ ATTENDANCE (organizer marks, student sees) ------------------------------ */
    // status: "present" | "absent" | ""  (empty = clear)
    async markAttendance(regId, status) {
      const u = requireRole("organizer", "admin");
      const r = findReg(regId);
      const e = ownEvent(u, r.eventId);
      requireHeld(e);
      setAttendance(r, e, str(status), u.name); save();
      return rv(r);
    },
    /** Same status for every participant of the event ("Mark all present") */
    async markAllAttendance(eventId, status) {
      const u = requireRole("organizer", "admin");
      const e = ownEvent(u, eventId);
      requireHeld(e);
      const list = load().registrations.filter(r => r.eventId === e.id);
      list.forEach(r => setAttendance(r, e, str(status), u.name)); save();
      return { updated: list.length };
    },

    /* ------------------------------ FEEDBACK (only students marked present) ------------------------------ */
    async submitFeedback(regId, b) {
      const u = requireRole("student");
      const r = findReg(regId);
      if (r.userId !== u.id) fail("This is not your registration");
      if (r.attendance !== "present") fail("Feedback is only for students marked present");
      const rating = Math.round(Number(b.rating));
      if (!(rating >= 1 && rating <= 5)) fail("Please choose a rating from 1 to 5 stars");
      const comment = str(b.comment);
      if (comment.length > 500) fail("Comment can be at most 500 characters");
      r.fb = { rating, comment, submittedAt: new Date().toISOString() }; save();
      return rv(r);
    },
    /** All feedback of one event - for the organizer */
    async eventFeedback(eventId) {
      const u = requireRole("organizer", "admin");
      ownEvent(u, eventId);
      return load().registrations.filter(r => r.eventId === Number(eventId) && r.fb)
        .map(r => ({ registrationId: r.id, name: r.name, enrollment: r.enrollment, rating: r.fb.rating, comment: r.fb.comment, submittedAt: r.fb.submittedAt }));
    },

    /* ------------------------------ CERTIFICATES (organizer uploads, present student downloads) ------------------------------ */
    // b = { fileName, fileType, data }   data = base64 data-URL made with FileReader.readAsDataURL
    async uploadCertificate(regId, b) {
      const u = requireRole("organizer", "admin");
      const r = findReg(regId);
      const e = ownEvent(u, r.eventId);
      requireHeld(e);
      if (r.attendance !== "present") fail("Certificates can only be given to students marked present");
      if (!str(b.data).startsWith("data:") || !str(b.data).includes(";base64,")) fail("Invalid file");
      if (!CERT_TYPES.includes(b.fileType)) fail("Only PDF, PNG or JPG files are allowed");
      if (b.data.length > MAX_CERT_CHARS) fail("File is too large (max about 1.4 MB in demo mode)");
      const before = r.cert;
      r.cert = { fileName: str(b.fileName) || "certificate", fileType: b.fileType, data: b.data, uploadedAt: new Date().toISOString() };
      try { save(); } catch (err) { r.cert = before; fail("Browser storage is full. Use a smaller file or reset demo data."); }
      addNotice("Certificate ready", `Your certificate for "${e.title}" is available. Open Attendance & Certificates to download it.`, r.userId, e.id, u.name);
      return rv(r);
    },
    async deleteCertificate(regId) {
      const u = requireRole("organizer", "admin");
      const r = findReg(regId);
      ownEvent(u, r.eventId);
      delete r.cert; save();
      return rv(r);
    },
    /** Returns { fileName, fileType, data } - allowed for that student, the event organizer and admin */
    async getCertificate(regId) {
      const u = requireLogin();
      const r = findReg(regId);
      const e = load().events.find(x => x.id === r.eventId);
      const ok = u.role === "admin" || (u.role === "student" && r.userId === u.id) || (e && e.organizerId === u.id);
      if (!ok) fail("You are not allowed to do this");
      if (!r.cert || r.attendance !== "present") fail("No certificate available");
      return { fileName: r.cert.fileName, fileType: r.cert.fileType, data: r.cert.data };
    },

    /* Handy for testing: wipes browser data and reloads demo data */
    resetDemo() { localStorage.removeItem(DB_KEY); Session.clear(); db = null; load(); }
  };
})();
