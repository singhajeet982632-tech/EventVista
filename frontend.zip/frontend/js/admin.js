/* =====================================================================
   admin.js  -  ADMIN PANEL  (admin.html)
   FR-12 manage users, events, registrations and system information
   ===================================================================== */
const user = guard("admin");

let allEvents = [], allUsers = [];
const refresh = () => onSection(location.hash.slice(1) || "overview");

function onSection(name) {
  if (name === "overview") loadOverview();
  if (name === "users") loadUsers();
  if (name === "events") loadEvents();
  if (name === "registrations") loadRegistrations();
  if (name === "announcements") loadAnnouncements();
  if (name === "system") loadSystem();
}

/* ---------------------------------------------------------- OVERVIEW */
function barsHTML(obj, labeler = x => x) {
  const entries = Object.entries(obj || {});
  const max = Math.max(1, ...entries.map(e => e[1]));
  return entries.length ? `<div class="bars">${entries.map(([k, v]) => `
    <div class="bar-row"><span>${esc(labeler(k))}</span><div class="track"><div class="fill" style="width:${v / max * 100}%"></div></div><b>${v}</b></div>`).join("")}</div>`
    : `<div class="empty">No data</div>`;
}
async function loadOverview() {
  const s = await safe(() => API.adminStats());
  if (!s) return;
  $("#stat-users").textContent = s.users;
  $("#stat-events").textContent = s.events;
  $("#stat-regs").textContent = s.registrations;
  $("#stat-notices").textContent = s.notices;
  $("#bars-cat").innerHTML = barsHTML(s.categories);
  $("#bars-status").innerHTML = barsHTML(s.statuses, k => CONFIG.STATUS_LABELS[k] || k);
  $("#bars-roles").innerHTML = barsHTML(s.roles);
}

/* ------------------------------------------------------------- USERS */
async function loadUsers() {
  allUsers = (await safe(() => API.adminUsers())) || [];
  renderUsers();
}
$("#user-search").oninput = () => renderUsers();
function renderUsers() {
  const q = $("#user-search").value.toLowerCase();
  const list = allUsers.filter(u => (u.name + u.email + u.enrollment).toLowerCase().includes(q));
  $("#users-table").innerHTML = `<div class="table-wrap"><table>
    <thead><tr><th>Name</th><th>Email</th><th>Role</th><th>Dept</th><th>Status</th><th>Actions</th></tr></thead>
    <tbody>${list.map(u => {
      const me = u.id === user.id;
      return `<tr><td><b>${esc(u.name)}</b><br><span class="muted small">${esc(u.enrollment) || ""}</span></td><td>${esc(u.email)}</td>
        <td>${me ? `<span class="badge role-${u.role}">${u.role}</span>` :
          `<select class="search-input" style="width:120px;padding:6px" data-role="${u.id}">${options(["student", "organizer", "admin"], u.role)}</select>`}</td>
        <td>${esc(u.department) || "-"}</td><td><span class="badge ${u.status}">${u.status}</span></td>
        <td>${me ? `<span class="muted small">(you)</span>` : `<div class="actions">
          <button class="btn btn-ghost btn-sm" data-block="${u.id}">${u.status === "blocked" ? "Unblock" : "Block"}</button>
          <button class="btn btn-ghost btn-sm" data-deluser="${u.id}">Delete</button></div>`}</td></tr>`;
    }).join("")}</tbody></table>${list.length ? "" : `<div class="empty">No users found.</div>`}</div>`;

  $$("[data-role]").forEach(s => s.onchange = async () => {
    await safe(() => API.adminUpdateUser(s.dataset.role, { role: s.value })); toast("Role updated"); loadUsers();
  });
  $$("[data-block]").forEach(b => b.onclick = async () => {
    const u = allUsers.find(x => x.id === Number(b.dataset.block));
    await safe(() => API.adminUpdateUser(u.id, { status: u.status === "blocked" ? "active" : "blocked" }));
    toast(u.status === "blocked" ? "User unblocked" : "User blocked"); loadUsers();
  });
  $$("[data-deluser]").forEach(b => b.onclick = async () => {
    if (!(await confirmBox("Delete this user permanently?", "Delete user"))) return;
    await safe(() => API.adminDeleteUser(b.dataset.deluser)); toast("User deleted"); loadUsers();
  });
}

/* ------------------------------------------------------------ EVENTS */
async function loadEvents() {
  allEvents = (await safe(() => API.getEvents())) || [];
  renderEvents();
}
$("#event-search").oninput = () => renderEvents();
$("#new-event-btn").onclick = () => openEventForm(null, refresh);
function renderEvents() {
  const q = $("#event-search").value.toLowerCase();
  const list = allEvents.filter(e => (e.title + e.category + e.organizerName).toLowerCase().includes(q));
  $("#events-table").innerHTML = `<div class="table-wrap"><table>
    <thead><tr><th>Event</th><th>Organizer</th><th>Date</th><th>Registered</th><th>Status</th><th>Actions</th></tr></thead>
    <tbody>${list.map(e => `<tr><td><b>${esc(e.title)}</b><br><span class="badge cat">${esc(e.category)}</span></td>
      <td>${esc(e.organizerName)}</td><td>${fmtDate(e.date)}</td><td>${e.registered} / ${e.capacity}</td><td>${statusBadge(e.status)}</td>
      <td><div class="actions">
        <button class="btn btn-ghost btn-sm" data-people="${e.id}">Participants</button>
        <button class="btn btn-ghost btn-sm" data-edit="${e.id}">Edit</button>
        <button class="btn btn-ghost btn-sm" data-delete="${e.id}">Delete</button></div></td></tr>`).join("")}
    </tbody></table>${list.length ? "" : `<div class="empty">No events found.</div>`}</div>`;
  const find = id => allEvents.find(e => e.id === Number(id));
  $$("[data-people]").forEach(b => b.onclick = () => openParticipants(find(b.dataset.people), refresh));
  $$("[data-edit]").forEach(b => b.onclick = () => openEventForm(find(b.dataset.edit), refresh));
  $$("[data-delete]").forEach(b => b.onclick = async () => {
    if (!(await confirmBox('Delete "' + find(b.dataset.delete).title + '" and all its registrations?', "Delete event"))) return;
    await safe(() => API.deleteEvent(b.dataset.delete)); toast("Event deleted"); refresh();
  });
}

/* ----------------------------------------------------- REGISTRATIONS */
async function loadRegistrations() {
  const list = (await safe(() => API.adminRegistrations())) || [];
  $("#regs-table").innerHTML = `<div class="table-wrap"><table>
    <thead><tr><th>Student</th><th>Enrollment</th><th>Event</th><th>Attendance</th><th>Phone</th><th>Registered</th><th></th></tr></thead>
    <tbody>${list.map(r => `<tr><td><b>${esc(r.name)}</b><br><span class="muted small">${esc(r.email)}</span></td>
      <td>${esc(r.enrollment) || "-"}</td><td>${esc(r.eventTitle)}</td><td>${attendanceBadge(r.attendance)}</td><td>${esc(r.phone)}</td><td>${fmtDate(r.registeredAt)}</td>
      <td><button class="btn btn-ghost btn-sm" data-remove="${r.id}">Remove</button></td></tr>`).join("")}
    </tbody></table>${list.length ? "" : `<div class="empty">No registrations yet.</div>`}</div>`;
  $$("[data-remove]").forEach(b => b.onclick = async () => {
    if (!(await confirmBox("Remove this registration?", "Remove"))) return;
    await safe(() => API.cancelRegistration(b.dataset.remove)); toast("Registration removed"); loadRegistrations();
  });
}

/* ------------------------------------------------------ ANNOUNCEMENTS */
async function loadAnnouncements() {
  await initAnnouncements("sec-announcements", "ann-list", "ann-form", () => API.getEvents());
}

/* ------------------------------------------------------------ SYSTEM */
async function loadSystem() {
  const s = await safe(() => API.adminStats());
  if (!s) return;
  const remote = API.mode === "remote";
  $("#system-info").innerHTML = `<div class="detail-list">
    <div class="item"><span>Application</span><b>${esc(CONFIG.APP_NAME)}</b></div>
    <div class="item"><span>Data source</span><b>${remote ? "Java backend (" + esc(CONFIG.API_BASE) + ")" : "Browser storage (demo mode)"}</b></div>
    <div class="item"><span>Total users</span><b>${s.users}</b></div>
    <div class="item"><span>Total events</span><b>${s.events}</b></div>
    <div class="item"><span>Total registrations</span><b>${s.registrations}</b></div>
    <div class="item"><span>Announcements</span><b>${s.notices}</b></div></div>
    ${remote ? "" : `<button class="btn btn-red" id="reset-demo">Reset demo data</button>
      <p class="muted small" style="margin-top:8px">Clears everything stored in this browser and reloads the sample data.</p>`}`;
  const r = $("#reset-demo");
  if (r) r.onclick = async () => {
    if (!(await confirmBox("Erase all data in this browser and reload demo data?", "Reset"))) return;
    API.resetDemo(); location.href = "index.html";
  };
}

/* ---------- start the panel (kept at the bottom so everything above is ready) ---------- */
if (user) initShell(user, onSection);
