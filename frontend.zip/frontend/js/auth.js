/* =====================================================================
   auth.js  -  logic for index.html  (FR-01 register, FR-02 login)
   ===================================================================== */
(function () {
  // Already logged in? go straight to the right panel.
  const s = Session.get();
  if (s && s.user) location.replace(panelFor(s.user.role));

  /** Which page belongs to which role. Rename pages here if you rename the files. */
  function panelFor(role) {
    return { student: "student.html", organizer: "organizer.html", admin: "admin.html" }[role] || "index.html";
  }

  // ---------- fill dropdowns from config.js ----------
  $("#reg-dept").innerHTML = `<option value="">Select department</option>` + options(CONFIG.DEPARTMENTS);

  // ---------- tabs: login / register ----------
  function showTab(name) {
    $$(".tabs button").forEach(b => b.classList.toggle("active", b.dataset.tab === name));
    $("#login-form").classList.toggle("hidden", name !== "login");
    $("#register-form").classList.toggle("hidden", name !== "register");
  }
  $$(".tabs button").forEach(b => b.onclick = () => showTab(b.dataset.tab));

  // organizer code box only when role = organizer
  $("#reg-role").onchange = e => {
    const org = e.target.value === "organizer";
    $("#org-code-field").classList.toggle("hidden", !org);
    $("#enroll-field").classList.toggle("hidden", org);
  };

  // ---------- LOGIN ----------
  $("#login-form").onsubmit = async e => {
    e.preventDefault();
    const err = $("#login-error"); err.textContent = "";
    try {
      const r = await API.login($("#login-email").value, $("#login-password").value);
      location.href = panelFor(r.user.role);
    } catch (ex) { err.textContent = ex.message; }
  };

  // demo account buttons: click to fill the login form
  $$("[data-demo]").forEach(b => b.onclick = () => {
    const [em, pw] = b.dataset.demo.split("|");
    $("#login-email").value = em; $("#login-password").value = pw; showTab("login");
  });

  // ---------- REGISTER ----------
  $("#register-form").onsubmit = async e => {
    e.preventDefault();
    const err = $("#register-error"); err.textContent = "";
    const data = Object.fromEntries(new FormData(e.target));
    if (data.password !== data.confirm) { err.textContent = "Passwords do not match"; return; }
    try {
      const r = await API.register(data);
      location.href = panelFor(r.user.role);
    } catch (ex) { err.textContent = ex.message; }
  };

  // ---------- upcoming highlights on the landing side (public, no login) ----------
  API.getEvents({ status: "open" }).then(list => {
    $("#highlights").innerHTML = list.slice(0, 3).map(ev => `
      <div class="mini-event"><div><b>${esc(ev.title)}</b><br><small>◷ ${fmtDate(ev.date)} · ⌖ ${esc(ev.venue)}</small></div>
      ${statusBadge(ev.status)}</div>`).join("") || `<p class="muted">No events open right now.</p>`;
  }).catch(() => { $("#highlights").innerHTML = ""; });
})();
