/* =====================================================================
   organizer.js  -  ORGANIZER PANEL  (organizer.html)
   FR-03 create events, FR-04 edit/remove, FR-10 participants, FR-11 announcements
   (The event form and participants window live in common.js)
   ===================================================================== */
const user = guard("organizer");

let myEvents = [];

function onSection(name) {
  if (name === "dashboard") loadDashboard();
  if (name === "events") loadEvents();
  if (name === "participants") loadParticipants();
  if (name === "attendance") loadAttendance();
  if (name === "feedback") loadFeedback();
  if (name === "certificates") loadCertificates();
  if (name === "announcements") loadAnnouncements();
}

async function fetchMine() { myEvents = (await safe(() => API.getEvents({ mine: true }))) || []; return myEvents; }

/** Called after create / edit / delete so the visible section refreshes */
const refresh = () => onSection(location.hash.slice(1) || "dashboard");

$("#new-event-btn").onclick = () => openEventForm(null, refresh);
$("#new-event-btn2").onclick = () => openEventForm(null, refresh);

/* ------------------------------------------------------------ DASHBOARD */
async function loadDashboard() {
  await fetchMine();
  const totalRegs = myEvents.reduce((s, e) => s + e.registered, 0);
  $("#stat-events").textContent = myEvents.length;
  $("#stat-open").textContent = myEvents.filter(e => e.status === "open").length;
  $("#stat-regs").textContent = totalRegs;
  $("#stat-seats").textContent = myEvents.reduce((s, e) => s + e.capacity, 0);

  // average rating from all feedback of my finished / running events
  let sum = 0, n = 0;
  for (const e of myEvents.filter(isHeld)) {
    for (const f of (await safe(() => API.eventFeedback(e.id))) || []) { sum += f.rating; n++; }
  }
  $("#stat-rating").textContent = n ? (sum / n).toFixed(1) + " ★" : "–";

  const sorted = [...myEvents].filter(e => e.status !== "completed").sort((a, b) => a.date.localeCompare(b.date));
  $("#dash-events").innerHTML = sorted.length ? sorted.slice(0, 5).map(e => {
    const pct = Math.min(100, Math.round(e.registered / e.capacity * 100));
    return `<div class="notice"><div class="n-ico">📅</div><div class="grow">
        <h4>${esc(e.title)} ${statusBadge(e.status)}</h4>
        <p class="muted small">◷ ${fmtDate(e.date)} · ${fmtTime(e.time)} · ⌖ ${esc(e.venue)}</p>
        <div class="progress ${pct >= 100 ? "full" : pct >= 80 ? "warn" : ""}" style="margin-top:8px"><span style="width:${pct}%"></span></div>
        <div class="when">${e.registered} / ${e.capacity} registered</div></div></div>`;
  }).join("") : `<div class="empty">You have no upcoming events. Create your first event!</div>`;
}

/* --------------------------------------------------------- MY EVENTS (FR-03/04) */
async function loadEvents() {
  await fetchMine();
  $("#events-table").innerHTML = myEvents.length ? `<div class="table-wrap"><table>
    <thead><tr><th>Event</th><th>Date & time</th><th>Venue</th><th>Registered</th><th>Status</th><th>Actions</th></tr></thead>
    <tbody>${myEvents.map(e => `<tr>
      <td><b>${esc(e.title)}</b><br><span class="badge cat">${esc(e.category)}</span></td>
      <td>${fmtDate(e.date)}<br><span class="muted small">${fmtTime(e.time)}</span></td>
      <td>${esc(e.venue)}</td><td>${e.registered} / ${e.capacity}</td><td>${statusBadge(e.status)}</td>
      <td><div class="actions">
        <button class="btn btn-ghost btn-sm" data-people="${e.id}">Participants</button>
        <button class="btn btn-ghost btn-sm" data-edit="${e.id}">Edit</button>
        <button class="btn btn-ghost btn-sm" data-delete="${e.id}">Delete</button></div></td></tr>`).join("")}
    </tbody></table></div>`
    : `<div class="card empty">You have not created any events yet.</div>`;
  bindEventButtons($("#events-table"));
}

function bindEventButtons(root) {
  const find = id => myEvents.find(e => e.id === Number(id));
  $$("[data-people]", root).forEach(b => b.onclick = () => openParticipants(find(b.dataset.people), refresh));
  $$("[data-edit]", root).forEach(b => b.onclick = () => openEventForm(find(b.dataset.edit), refresh));
  $$("[data-delete]", root).forEach(b => b.onclick = async () => {
    if (!(await confirmBox('Delete "' + find(b.dataset.delete).title + '" and all its registrations?', "Delete event"))) return;
    await safe(() => API.deleteEvent(b.dataset.delete));
    toast("Event deleted"); refresh();
  });
}

/* ------------------------------------------------------ PARTICIPANTS (FR-10) */
async function loadParticipants() {
  await fetchMine();
  $("#people-list").innerHTML = myEvents.length ? myEvents.map(e => `
    <div class="notice"><div class="n-ico">👥</div><div class="grow"><h4>${esc(e.title)} ${statusBadge(e.status)}</h4>
      <p class="muted small">${fmtDate(e.date)} · ${e.registered} of ${e.capacity} registered</p></div>
      <button class="btn btn-sm" data-people="${e.id}">View participants</button></div>`).join("")
    : `<div class="empty">Create an event to start receiving registrations.</div>`;
  bindEventButtons($("#people-list"));
}

/* ------------------------------------------------------ ANNOUNCEMENTS (FR-11) */
async function loadAnnouncements() {
  await fetchMine();
  // initAnnouncements fills the event dropdown, binds the form and loads the list
  await initAnnouncements("sec-announcements", "ann-list", "ann-form", async () => myEvents);
}

/* ====================================================================
   ATTENDANCE / FEEDBACK / CERTIFICATES  (organizer side)
   Only events whose day has come (event day or later) are listed here.
   ==================================================================== */
const picked = { att: null, fb: null, cert: null };      // remembers the chosen event in each section
const heldEvents = () => myEvents.filter(isHeld).sort((a, b) => b.date.localeCompare(a.date));

/** Event dropdown shared by the 3 sections. Returns the selected event (or null). */
function eventPicker(key, boxId, extraButtons = "") {
  const list = heldEvents();
  const box = $(boxId);
  if (!list.length) {
    box.innerHTML = `<div class="card empty">Nothing here yet - this opens on the day of your event.</div>`;
    return null;
  }
  if (!list.find(e => e.id === picked[key])) picked[key] = list[0].id;
  box.innerHTML = `<div class="toolbar"><select class="search-input" id="${key}-event">${list.map(e =>
      `<option value="${e.id}" ${e.id === picked[key] ? "selected" : ""}>${esc(e.title)} - ${fmtDate(e.date)}</option>`).join("")}</select>${extraButtons}</div>
    <div id="${key}-content"></div>`;
  return list.find(e => e.id === picked[key]);
}

/* ------------------------------------------------------------ ATTENDANCE */
async function loadAttendance() {
  await fetchMine();
  const ev = eventPicker("att", "#att-body", `<button class="btn btn-green" id="att-all-p">✔ Mark all present</button><button class="btn btn-ghost" id="att-all-a">✖ Mark all absent</button>`);
  if (!ev) return;
  $("#att-event").onchange = e => { picked.att = Number(e.target.value); loadAttendance(); };
  $("#att-all-p").onclick = () => markAll(ev, "present");
  $("#att-all-a").onclick = () => markAll(ev, "absent");
  await renderAttendance(ev);
}
async function renderAttendance(ev) {
  const regs = (await safe(() => API.eventRegistrations(ev.id))) || [];
  const count = s => regs.filter(r => r.attendance === s).length;
  $("#att-content").innerHTML = `
    <div class="stats">
      <div class="card stat"><div class="ico green">✔</div><div><div class="label">Present</div><div class="value">${count("present")}</div></div></div>
      <div class="card stat"><div class="ico red">✖</div><div><div class="label">Absent</div><div class="value">${count("absent")}</div></div></div>
      <div class="card stat"><div class="ico blue">❓</div><div><div class="label">Not marked</div><div class="value">${count("")}</div></div></div>
    </div>` + (regs.length ? `<div class="table-wrap"><table>
      <thead><tr><th>#</th><th>Name</th><th>Enrollment</th><th>Dept / Year</th><th>Status</th><th>Mark attendance</th></tr></thead>
      <tbody>${regs.map((r, i) => `<tr><td>${i + 1}</td><td>${esc(r.name)}</td><td>${esc(r.enrollment) || "-"}</td>
        <td>${esc(r.department) || "-"} / ${esc(r.year) || "-"}</td><td>${attendanceBadge(r.attendance)}</td>
        <td><div class="seg">
          <button class="${r.attendance === "present" ? "on-present" : ""}" data-mark="${r.id}|present">Present</button>
          <button class="${r.attendance === "absent" ? "on-absent" : ""}" data-mark="${r.id}|absent">Absent</button></div></td></tr>`).join("")}
      </tbody></table></div><p class="muted small" style="margin-top:10px">Tip: click the highlighted button again to clear the mark.</p>`
    : `<div class="card empty">Nobody registered for this event.</div>`);

  $$("[data-mark]", $("#att-content")).forEach(b => b.onclick = async () => {
    const [id, status] = b.dataset.mark.split("|");
    const r = regs.find(x => x.id === Number(id));
    const next = r.attendance === status ? "" : status;          // clicking the active button clears it
    // leaving "present" deletes feedback + certificate -> ask first
    if (r.attendance === "present" && next !== "present" && (r.feedback || r.certificate) &&
        !(await confirmBox("This student's feedback and certificate will be removed. Continue?", "Yes, change"))) return renderAttendance(ev);
    await safe(() => API.markAttendance(id, next));
    renderAttendance(ev);
  });
}
async function markAll(ev, status) {
  if (!(await confirmBox(`Mark ALL participants as ${status}?`, "Yes, mark all"))) { return loadAttendance(); }
  await safe(() => API.markAllAttendance(ev.id, status));
  toast("Attendance updated");
  loadAttendance();
}

/* -------------------------------------------------------------- FEEDBACK */
async function loadFeedback() {
  await fetchMine();
  const ev = eventPicker("fb", "#fb-body");
  if (!ev) return;
  $("#fb-event").onchange = e => { picked.fb = Number(e.target.value); loadFeedback(); };
  const list = (await safe(() => API.eventFeedback(ev.id))) || [];
  const regs = (await safe(() => API.eventRegistrations(ev.id))) || [];
  const present = regs.filter(r => r.attendance === "present").length;
  const avg = list.length ? list.reduce((s, f) => s + f.rating, 0) / list.length : 0;
  $("#fb-content").innerHTML = `
    <div class="stats">
      <div class="card stat"><div class="ico red">⭐</div><div><div class="label">Average rating</div><div class="value">${list.length ? avg.toFixed(1) : "–"}</div></div></div>
      <div class="card stat"><div class="ico purple">💬</div><div><div class="label">Feedback received</div><div class="value">${list.length} <small class="muted" style="font-size:.9rem">of ${present} present</small></div></div></div>
    </div>` + (list.length ? list.sort((a, b) => b.submittedAt.localeCompare(a.submittedAt)).map(f => `
      <div class="card fb-card"><div class="who"><div><b>${esc(f.name)}</b> <span class="muted small">${esc(f.enrollment)}</span></div>${starsHTML(f.rating)}</div>
        <p>${f.comment ? esc(f.comment) : `<span class="muted">(no comment)</span>`}</p>
        <div class="muted small" style="margin-top:6px">${fmtStamp(f.submittedAt)}</div></div>`).join("")
    : `<div class="card empty">No feedback yet. Only students marked present can send feedback.</div>`);
}

/* ---------------------------------------------------------- CERTIFICATES */
async function loadCertificates() {
  await fetchMine();
  const ev = eventPicker("cert", "#cert-body");
  if (!ev) return;
  $("#cert-event").onchange = e => { picked.cert = Number(e.target.value); loadCertificates(); };
  await renderCertificates(ev);
}
async function renderCertificates(ev) {
  const all = (await safe(() => API.eventRegistrations(ev.id))) || [];
  const regs = all.filter(r => r.attendance === "present");        // certificates only for present students
  const done = regs.filter(r => r.certificate).length;
  $("#cert-content").innerHTML = regs.length ? `
    <p class="muted" style="margin-bottom:14px">${done} of ${regs.length} present students have a certificate.</p>
    <div class="table-wrap"><table>
      <thead><tr><th>#</th><th>Name</th><th>Enrollment</th><th>Certificate</th><th>Actions</th></tr></thead>
      <tbody>${regs.map((r, i) => `<tr><td>${i + 1}</td><td>${esc(r.name)}</td><td>${esc(r.enrollment) || "-"}</td>
        <td>${r.certificate ? `<span class="badge present">Uploaded</span><div class="muted small" style="margin-top:4px">${esc(r.certificate.fileName)}</div>`
                            : `<span class="badge pending">Not uploaded</span>`}</td>
        <td><div class="actions"><button class="btn btn-sm" data-up="${r.id}">${r.certificate ? "Replace" : "⬆ Upload"}</button>
          ${r.certificate ? `<button class="btn btn-ghost btn-sm" data-down="${r.id}">View</button><button class="btn btn-ghost btn-sm" data-rm="${r.id}">Remove</button>` : ""}</div></td></tr>`).join("")}
      </tbody></table></div>`
    : `<div class="card empty">No student is marked present yet.<br><br><button class="btn" onclick="showSection('attendance')">Go to Attendance</button></div>`;

  $$("[data-up]", $("#cert-content")).forEach(b => b.onclick = () => pickCertificateFile(async file => {
    await safe(async () => { await API.uploadCertificate(b.dataset.up, file); toast("Certificate uploaded"); });
    renderCertificates(ev);
  }));
  $$("[data-down]", $("#cert-content")).forEach(b => b.onclick = () => downloadCertificate(b.dataset.down));
  $$("[data-rm]", $("#cert-content")).forEach(b => b.onclick = async () => {
    if (!(await confirmBox("Remove this certificate?", "Remove"))) return renderCertificates(ev);
    await safe(() => API.deleteCertificate(b.dataset.rm)); toast("Certificate removed"); renderCertificates(ev);
  });
}

/* ---------- start the panel (kept at the bottom so everything above is ready) ---------- */
if (user) initShell(user, onSection);
